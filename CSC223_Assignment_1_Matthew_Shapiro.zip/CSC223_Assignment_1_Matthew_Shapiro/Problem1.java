/*********************************************************************/
/**********     Author:             Matthew Shapiro         **********/
/**********     Organization:       HCC                     **********/
/**********     Project:            Ch. 1 Problem 1.3       **********/
/**********     Date Last Modified: 2016-09-11              **********/
/*********************************************************************/

class Problem1 {

    public static void main(String[] args) {

        System.out.println("\n************************************************************");
        
        // Print your name
        System.out.println("Name:\t\tMatthew Shapiro");
        // Print your birthday
        System.out.println("Birthday:\tNovember 8th, 1983");
        // Print your hobbies
        System.out.println("Hobbies:");
        System.out.println("\t\tRiding my bike");
        System.out.println("\t\tSwimming");
        System.out.println("\t\tLearning to program");
        // Print your favorite book
        System.out.println("Favorite book:\t'His Dark Materials' by Philip Pullman");
        // Print your favorite movie
        System.out.println("Favorite movie:\tInherent Vice");

        System.out.println("************************************************************\n");
    }
}