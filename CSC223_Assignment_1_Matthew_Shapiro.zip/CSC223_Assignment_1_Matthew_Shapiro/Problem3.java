/*********************************************************************/
/**********     Author:             Matthew Shapiro         **********/
/**********     Organization:       HCC                     **********/
/**********     Project:            Ch. 1 Problem 1.10      **********/
/**********     Date Last Modified: 2016-09-11              **********/
/*********************************************************************/

class Problem3 {

    public static void main(String[] args) {

        System.out.println("\n************************************************************\n");

        System.out.println("MMMM   MMMM   AAAAAAA    SSSSSS");
        System.out.println("MMMMM MMMMM  AAAA AAAA  SSSS");
        System.out.println("MMMMMMMMMMM  AAA   AAA   SSSSS");
        System.out.println("MMM MMM MMM  AAAAAAAAA     SSSS");
        System.out.println("MMM  M  MMM  AAAAAAAAA    SSSSS");
        System.out.println("MMM     MMM  AAA   AAA  SSSSS");

        System.out.println("\n************************************************************\n");
    }

}


