/*********************************************************************/
/**********     Author:             Matthew Shapiro         **********/
/**********     Organization:       HCC                     **********/
/**********     Project:            Ch. 1 Problem 1.9       **********/
/**********     Date Last Modified: 2016-09-11              **********/
/*********************************************************************/

class Problem2 {

    public static void main(String[] args) {

        // print newline
        System.out.println("\n");

        System.out.println("    *");
        System.out.println("   ***");
        System.out.println("  *****");
        System.out.println(" *******");
        System.out.println("*********");
        System.out.println(" *******");
        System.out.println("  *****");
        System.out.println("   ***");
        System.out.println("    *");

    }

}



